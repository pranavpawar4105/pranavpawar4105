#include<stdio.h>
int main()
{
	int num1 = 5;
	int num2 = 2;
	int temp;
	
	temp = num1;
	num1 = num2;
	num2 = temp;
	printf("value of num1=%d and value of num2=%d",num1,num2);
}	